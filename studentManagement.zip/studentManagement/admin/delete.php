<?php
include("./include/db.php");
session_start();
$id = $_GET['id'];

// sql to delete a record
$sql = "DELETE FROM student WHERE usn = '$id'";

if (mysqli_query($con, $sql)) {
    mysqli_close($con);
    header('Location: removeStudent.php');
    exit;
} else {
    echo "Error deleting record";
}