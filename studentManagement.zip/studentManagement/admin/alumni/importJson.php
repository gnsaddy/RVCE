<?php
include("../include/db.php");
session_start();
$result = $con->query("SELECT * FROM alumni ");
$fname = "Alumni";
if ($result->num_rows > 0) {
    $arr = [];
    $inc = 0;
    while ($row = $result->fetch_assoc()) {
        # code...
        $jsonArrayObject = (array('usn' => $row["usn"], 'name' => $row["name"],
            'placed_year' => $row["placed_year"],'company' => $row["company"],
            'email' => $row["email"],'contact' => $row["contact"],'salary' => $row["salary"]));
        $arr['Alumni details'][$inc] = $jsonArrayObject;
        $inc++;
    }
    $json_array = json_encode($arr);

} else {
    echo "0 results";
}


header("Content-Type: application/json");
header("Content-Disposition: attachment; filename=$fname.json");
echo $json_array;
?>

