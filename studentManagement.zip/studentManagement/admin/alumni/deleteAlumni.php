<?php
include("../include/db.php");
session_start();
$id = $_GET['id'];

// sql to delete a record
$sql = "DELETE FROM alumni WHERE usn = '$id'";

if (mysqli_query($con, $sql)) {
    mysqli_close($con);
    header('Location: removeAlumni.php');
    exit;
} else {
    echo "Error deleting record";
}