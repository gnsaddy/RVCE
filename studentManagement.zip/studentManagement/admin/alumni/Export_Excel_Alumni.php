<?php
include("../include/db.php");

session_start();
$output = '';
if(isset($_POST["export_excel"]))
{
    $sql = "select * from alumni";
    $fname = "Alumni";
    $result = mysqli_query($con,$sql);
    if(mysqli_num_rows($result)>0)
    {
        $output .='
            <table class="table" bordered="1">
            <tr>
                                    <th>USN</th>
                                    <th>Name</th>
                                    <th>Placed Year</th>
                                    <th>Company</th>
                                    <th>Email</th>
                                    <th>Contact</th>
                                    <th>Salary(LPA)</th>
                                    
            </tr>
        ';
        while ($row=mysqli_fetch_array($result))
        {
            $output .= '
                <tr>
                    <td>'.$row["usn"].'</td>
                    <td>'.$row["name"].'</td>
                    <td>'.$row["placed_year"].'</td>
                     <td>'.$row["company"].'</td>
                    <td>'.$row["email"].'</td>
                    <td>'.$row["contact"].'</td>
                    <td>'.$row["salary"].'</td>
                  
                </tr>
            ';
        }
        $output .='</table>';

        // header("Content-Type: application/vnd.ms-excel;charset=utf-8");
        header("Content-Type: application/vnd.openxmlformats-officedocument.speadsheetml.sheet;charset=utf-8");

        header("Content-Disposition: attachment; filename=$fname.xls");
        echo $output;
    }
}
?>