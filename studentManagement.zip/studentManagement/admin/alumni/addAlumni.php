<?php

include("../include/db.php");
session_start();

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title> Add Alumni</title>
    <link rel="icon" type="image/png" href="../img/rvlogo.png">

    <!-- Custom fonts for this template-->
    <link href="../vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <!-- Page level plugin CSS-->
    <link href="../vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="../css/sb-admin.css" rel="stylesheet">

</head>

<body id="page-top">

<!--header start-->
<?php
include("./headerAlumni.php");
?>

<div id="content-wrapper">
    <div class="container-fluid">
        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="../dashboard.php">Dashboard</a>
            </li>
            <li class="breadcrumb-item active">Add Alumni</li>
        </ol>
        <!--     content add here -->
        <div class="card">
            <div class="container-fluid">
                <h5 class="mt-3">Click to upload to Database</h5>
                <!--                    start of upload card-->
                <div class="row">
                    <div class="col-sm col-md-12 col-lg-12">
                        <div class="row">
                            <div class="col-sm col-md-3 col-lg-3">
                                <div class="mt-3">
                                    <button type="submit" class="btn btn-primary">
                                        <a href="./uploadAlumni.php" class="text-light"> Excel to database</a>
                                    </button>
                                </div>
                            </div>
                            <div class="col-sm col-md-3 col-lg-3">
                                <div class="mt-3">
                                    <button type="submit" class="btn btn-primary">
                                        <a href="./uploadAlumni.php" class="text-light"> CSV to database</a>
                                    </button>
                                </div>
                            </div>
                            <div class="col-sm col-md-3 col-lg-3">
                                <div class="mt-3">
                                    <form action="Export_Excel_Alumni.php" method="POST">
                                        <input type="submit" name="export_excel" class="btn btn-primary" value="Export to Excel"/>
                                    </form>
                                </div>
                            </div>
                            <div class="col-sm col-md-3 col-lg-3">
                                <div class="mt-3">
                                    <button type="submit" class="btn btn-primary">
                                        <a href="./importJson.php" class="text-light"> Export to JSON</a>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <br>
                <form action="./addAlumni.php" method="post">
                    <div class="card"><br>
                        <div class="row">
                            <div class="col-sm col-md-12 col-lg-12">
                                <div class="row">
                                    <div class="col-sm col-md-6 col-lg-6">
                                        <div class="form-label-group" style="margin: 2%;">
                                            <input type="text" id="usn" name="usn" class="form-control"
                                                   placeholder="USN" required autofocus>
                                            <label for="usn">USN</label>
                                        </div>
                                    </div>
                                    <div class="col-sm col-md-6 col-lg-6">
                                        <div class="form-label-group" style="margin: 2%;">
                                            <input type="text" id="studentName" name="studentName" class="form-control"
                                                   placeholder="Student Name" required autofocus>
                                            <label for="studentName">Student Name</label>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-sm col-md-6 col-lg-6">
                                        <div class="form-label-group" style="margin: 2%;">
                                            <input type="number" id="placedYear" name="placedYear" class="form-control"
                                                   placeholder="Placed Year" min="2015" max="2100" required autofocus>
                                            <label for="placedYear">Placed Year</label>
                                        </div>
                                    </div>
                                    <div class="col-sm col-md-6 col-lg-6">
                                        <div class="form-label-group" style="margin: 2%;">
                                            <input type="text" id="offer" name="offer" class="form-control"
                                                   placeholder="Company" required autofocus>
                                            <label for="offer">Company</label>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-sm col-md-6 col-lg-6">
                                        <div class="form-label-group" style="margin: 2%;">
                                            <input type="email" id="email" name="email" class="form-control"
                                                   placeholder="Email" required autofocus>
                                            <label for="email">Email</label>
                                        </div>
                                    </div>
                                    <div class="col-sm col-md-6 col-lg-6">
                                        <div class="form-label-group" style="margin: 2%;">
                                            <input type="tel" id="contact" name="contact" class="form-control"
                                                   placeholder="Conatct" required autofocus>
                                            <label for="contact">Conatct</label>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-sm col-md-6 col-lg-6">
                                        <div class="form-label-group" style="margin: 2%;">
                                            <input type="text" id="salary" name="salary" class="form-control"
                                                   placeholder="Salary">
                                            <label for="salary">Salary</label>
                                        </div>
                                    </div>

                                    <div class="col-sm col-md-2 col-lg-2">
                                        <div class="form-label-group" style="margin-left: 10%; margin-top: 10%;">
                                            <button class="btn btn-md btn-primary btn-block text-uppercase"
                                                    name="submit"
                                                    type="submit"><i class="fa fa-save"></i>&nbsp; Save
                                            </button>
                                        </div>
                                    </div>
                                    <div class="col-sm col-md-2 col-lg-2">
                                        <div class="form-label-group" style="margin-left: 10%; margin-top: 10%;">
                                            <button class="btn btn-md btn-primary btn-block text-uppercase"
                                                    name="reset"
                                                    type="reset"><i class="fa fa-spinner"></i>&nbsp; Reset
                                            </button>
                                        </div>
                                    </div>
                                </div>
                                <br>
                            </div>
                        </div>
                    </div>
                </form>
                <br>
            </div>
        </div>
    </div>


    <!--end  /.container-fluid -->
    <!---------------------------------------------------------------------------------------------------------->

</div>
<!-- /.content-wrapper -->
</div>
<!-- /#wrapper -->
<!-------------------------------------------------------------------------------------------------------->
<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>

<script>
    document.getElementById("placedYear");
    .oninput = e => console.log(new Date(e.target.valueAsNumber, 0, 1))
</script>
<!-- php for insert into student-->

<?php
if (isset($_POST['submit'])) {
    $usn = $_POST['usn'];
    $name = $_POST['studentName'];
    $year = $_POST['placedYear'];
    $offer = $_POST['offer'];
    $email = $_POST['email'];
    $contact = $_POST['contact'];
    $salary = $_POST['salary'];

    $query = "INSERT INTO alumni (usn, name, placed_year, company, email, contact, salary)
                values ('$usn','$name',$year,'$offer','$email',$contact,'$salary')";


    $queryCheckUsn = mysqli_query($con, "select usn from alumni where usn= '$usn' ");

    if (mysqli_num_rows($queryCheckUsn) >= 1) {
        $msg = "$usn is already existed, Try for new USN";
        echo "<script type='text/javascript'> alert('$msg');</script>";
    } else {
        $data = mysqli_query($con, $query);
        echo '<script language="javascript">';
        echo "alert('$usn is successfully inserted')";
        echo '</script>';
    }
}
?>


<!-- Bootstrap core JavaScript-->
<script src="../vendor/jquery/jquery.min.js"></script>
<script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

<!-- Core plugin JavaScript-->
<script src="../vendor/jquery-easing/jquery.easing.min.js"></script>

<!-- Page level plugin JavaScript-->
<script src="../vendor/chart.js/Chart.min.js"></script>
<script src="../vendor/datatables/jquery.dataTables.js"></script>
<script src="../vendor/datatables/dataTables.bootstrap4.js"></script>

<!-- Custom scripts for all pages-->
<script src="../js/sb-admin.min.js"></script>

<!-- Demo scripts for this page-->
<script src="../js/demo/datatables-demo.js"></script>
<script src="../js/demo/chart-area-demo.js"></script>


</body>

</html>