<?php
include("./include/db.php");
?>

<script>
    var myData=[<?php
        while($info=mysqli_fetch_array($data))
            echo $info['usn'].','; /* We use the concatenation operator '.' to add comma delimiters after each data value. */
        ?>];
    <?php
    $data=mysqli_query($con,"SELECT start_batch,end_batch,count(company) FROM student");
    ?>
    var myLabels=[<?php
        while($info=mysqli_fetch_array($data))
            echo '"'.$info['usn'].'",'; /* The concatenation operator '.' is used here to create string values from our database names. */
        ?>];
</script>

<?php
/* Close the connection */
$con->close();
?>
