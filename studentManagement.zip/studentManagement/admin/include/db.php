<?php
$con = mysqli_connect("localhost","root","","placementdetails");
if($con){
}else{
    die("can not connect to include".mysqli_connect_error());
}
?>