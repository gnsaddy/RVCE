<?php
$con = mysqli_connect("localhost","root","","crackthecode");
if($con){
}else{
    die("can not connect to include".mysqli_connect_error());
}
?>