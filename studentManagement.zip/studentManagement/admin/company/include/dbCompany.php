<?php
$conCom = mysqli_connect("localhost","root","","placementdetails");
if($conCom){
}else{
    die("can not connect to include".mysqli_connect_error());
}
?>


