<?php
include("../include/dbCompany.php");
session_start();
$result = $conCom->query("SELECT * FROM company_visited_2018 ");
$fname = "Company2018-19";
if ($result->num_rows > 0) {
    $arr = [];
    $inc = 0;
    while ($row = $result->fetch_assoc()) {
        # code...
        $contact = $row['hrcontact'];
        if($row["hrcontact"]==0)
            $contact = '';
        $jsonArrayObject = (array('name' => $row["name"], 'ctc' => $row["ctc"],'hrname' => $row["hrname"],
            'hremail' => $row["hremail"],'hrcontact' => $contact));
        $arr['Company Details'][$inc] = $jsonArrayObject;
        $inc++;
    }
    $json_array = json_encode($arr);

} else {
    echo "0 results";
}


header("Content-Type: application/json");
header("Content-Disposition: attachment; filename=$fname.json");
echo $json_array;
?>

