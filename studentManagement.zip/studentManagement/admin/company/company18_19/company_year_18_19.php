<?php

include("../include/dbCompany.php");
session_start();

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title> Add | Company</title>
    <link rel="icon" type="image/png" href="../../img/rvlogo.png">

    <!-- Custom fonts for this template-->
    <link href="../../vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <!-- Page level plugin CSS-->
    <link href="../../vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="../../css/sb-admin.css" rel="stylesheet">
</head>

<body id="page-top">

<!--header start-->
<?php
include("./headerCompany_18_19.php");
?>

<div id="content-wrapper">
    <div class="container-fluid">
        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="../../../admin/dashboard.php">Dashboard</a>
            </li>
            <li class="breadcrumb-item active">Add Company 2018-19</li>
        </ol>
        <!--     content add here -->
        <div class="card">
            <div class="container-fluid">
                <h5 class="mt-3">Click to upload to Database</h5>
                <!--                    start of upload card-->
                <div class="row">
                    <div class="col-sm col-md-12 col-lg-12">
                        <div class="row">
                            <div class="col-sm col-md-3 col-lg-3">
                                <div class="mt-3">
                                    <button type="submit" class="btn btn-primary">
                                        <a href="upload_company_18_19.php" class="text-light"> Excel to database</a>
                                    </button>
                                </div>
                            </div>
                            <div class="col-sm col-md-3 col-lg-3">
                                <div class="mt-3">
                                    <button type="submit" class="btn btn-primary">
                                        <a href="#" class="text-light"> CSV to database</a>
                                    </button>
                                </div>
                            </div>
                            <div class="col-sm col-md-3 col-lg-3">
                                <div class="mt-3">
                                    <form action="exportExcel_company_18_19.php" method="POST">
                                        <input type="submit" name="export_excel" class="btn btn-primary"
                                               value="Export to Excel"/>
                                    </form>
                                </div>
                            </div>
                            <div class="col-sm col-md-3 col-lg-3">
                                <div class="mt-3">
                                    <button type="submit" class="btn btn-primary">
                                        <a href="./company_json_18_19.php" class="text-light"> Export to JSON</a>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <br>
                <form action="company_year_18_19.php" method="post">
                    <div class="card"><br>
                        <div class="row">
                            <div class="col-sm col-md-12 col-lg-12">
                                <div class="row">
                                    <div class="col-sm col-md-6 col-lg-6">
                                        <div class="form-label-group" style="margin: 2%;">
                                            <input type="text" id="name" name="name" class="form-control"
                                                   placeholder="Name" required autofocus>
                                            <label for="name">Name</label>
                                        </div>
                                    </div>
                                    <div class="col-sm col-md-6 col-lg-6">
                                        <div class="form-label-group" style="margin: 2%;">
                                            <input type="text" id="ctc" name="ctc" class="form-control"
                                                   placeholder="CTC" required autofocus>
                                            <label for="ctc">CTC</label>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">

                                    <div class="col-sm col-md-6 col-lg-6">
                                        <div class="form-label-group" style="margin: 2%;">
                                            <input type="text" id="hrname" name="hrname" class="form-control"
                                                   placeholder="HR Name">
                                            <label for="hrname">HR Name</label>
                                        </div>
                                    </div>


                                    <div class="col-sm col-md-6 col-lg-6">
                                        <div class="form-label-group" style="margin: 2%;">
                                            <input type="email" id="hremail" name="hremail" class="form-control"
                                                   placeholder="HR Email">
                                            <label for="hremail">HR Email</label>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">

                                    <div class="col-sm col-md-6 col-lg-6">
                                        <div class="form-label-group" style="margin: 2%;">
                                            <input type="text" id="hrcontact" name="hrcontact" class="form-control"
                                                   placeholder="HR Contact">
                                            <label for="hrcontact">HR Contact</label>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-sm col-md-2 col-lg-2">
                                        <div class="form-label-group" style="margin-left: 10%; margin-top: 10%;">
                                            <button class="btn btn-md btn-primary btn-block text-uppercase text-justify"
                                                    name="submit"
                                                    type="submit"><i class="fa fa-save"></i>&nbsp; Save
                                            </button>
                                        </div>
                                    </div>
                                    <div class="col-sm col-md-2 col-lg-2">
                                        <div class="form-label-group" style="margin-left: 10%; margin-top: 10%;">
                                            <button class="btn btn-md btn-primary btn-block text-uppercase text-justify"
                                                    name="reset"
                                                    type="reset"><i class="fa fa-spinner"></i>&nbsp; Reset
                                            </button>
                                        </div>
                                    </div>
                                </div>
                                <br>
                            </div>
                        </div>
                    </div>
                </form>
                <br>
                <hr>
                <div class="card mb-3">
                    <div class="card-header">
                        <i class="fas fa-table"></i>
                        Company Data
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <?php
                            $sql = "select name,cid from company_visited_2018";
                            $data = mysqli_query($conCom, $sql);
                            $total = mysqli_num_rows($data);
                            if ($total != 0) {
                            ?>
                            <table class="table table-bordered" id="dataTable" width="50%" cellspacing="0">
                                <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Add Student</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php
                                while ($row = mysqli_fetch_assoc($data)) {
                                    echo "<tr><td>" . $row['name'] . "</td>";
                                    echo "<td>
                                      <a href='------?id=" . $row['cid'] . "'> 
                                      &nbsp;&nbsp;<i class='fa fa-trash '></i> </a></td>
                                      </tr>";
                                }
                                } else {
                                    echo "No records found!";
                                }

                                //                                $conCom->close();

                                ?>
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <br>
            </div>
        </div>
    </div>
    <!--end  /.container-fluid -->
    <!---------------------------------------------------------------------------------------------------------->
</div>
<!-- /.content-wrapper -->
</div>
<!-- /#wrapper -->
<!-------------------------------------------------------------------------------------------------------->
<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>

    </tbody>
</table>
</div>
</div>

</div>
</div>
</div>
<!--end  /.container-fluid -->
<!---------------------------------------------------------------------------------------------------------->
</div>
<!-- /.content-wrapper -->
</div>
<!-- /#wrapper -->
<!-------------------------------------------------------------------------------------------------------->
<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>

<?php
if (isset($_POST['submit'])) {

    $name = $_POST['name'];
    $ctc = $_POST['ctc'];
    if(empty($_POST['hrname']) || ($_POST['hrname']==" ") || is_null($_POST['hrname'])/*|| is($_POST['hrname'])*/)
    {
        $hrname = " ";
    }
    else
    {
        $hrname = $_POST['hrname'];
    }

    if(empty($_POST['hremail']) || ($_POST['hremail']==" ") || is_null($_POST['hremail'])/*|| isset($_POST['hremail'])*/)
    {
        $hremail = " ";
    }
    else
    {
        $hremail = $_POST['hremail'];
    }

    if(empty($_POST['hrcontact']) || ($_POST['hrcontact']==" ")  || is_null($_POST['hrcontact'])/*|| isset($_POST['hrcontact'])*/)
    {
        $hrcontact = 0;
    }
    else
    {
        $hrcontact = $_POST['hrcontact'];
    }

    $year = 2018;

    $query = "INSERT INTO company_visited_2018 (name, ctc, year, hrname, hremail, hrcontact)
                values ('$name','$ctc',$year,'$hrname','$hremail',$hrcontact)";

    $queryCheckName = mysqli_query($conCom, "select name from company_visited_2018 where name= '$name' ");


    $total = 0;
    $total = mysqli_num_rows($queryCheckName);
    $bool = true;
    if($total) {
        $rows = 0;
        while ($rows = mysqli_fetch_assoc($queryCheckName)) {
            if ($rows['name'] == $name) {
                echo "<script>alert('$name is already existing');</script>";
                $bool = false;
            }
        }
    }
    if($bool) {
        $data = mysqli_query($conCom, $query);
        echo '<script language="javascript">';
        echo "alert('$name is successfully inserted')";
        echo '</script>';

        //header('refresh:0,content=0');
        echo "<script> window.history.replaceState( null, null, window.location.href='company_year_18_19.php')</script>";
    }
}
?>


<!-- Bootstrap core JavaScript-->
<script src="../../vendor/jquery/jquery.min.js"></script>
<script src="../../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

<!-- Core plugin JavaScript-->
<script src="../../vendor/jquery-easing/jquery.easing.min.js"></script>

<!-- Page level plugin JavaScript-->
<script src="../../vendor/chart.js/Chart.min.js"></script>
<script src="../../vendor/datatables/jquery.dataTables.js"></script>
<script src="../../vendor/datatables/dataTables.bootstrap4.js"></script>

<!-- Custom scripts for all pages-->
<script src="../../js/sb-admin.min.js"></script>

<!-- Demo scripts for this page-->
<script src="../../js/demo/datatables-demo.js"></script>
<script src="../../js/demo/chart-area-demo.js"></script>


</body>

</html>