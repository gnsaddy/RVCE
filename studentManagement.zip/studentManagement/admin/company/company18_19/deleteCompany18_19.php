<?php
include("../include/dbCompany.php");
session_start();
$id = $_GET['id'];

// sql to delete a record
$sql = "DELETE FROM company_visited18_19 WHERE name = '$id'";

if (mysqli_query($conCom, $sql)) {
    mysqli_close($conCom);
    header('Location: removeCompany_18_19.php');
    exit;
} else {
    echo "Error deleting record";
}