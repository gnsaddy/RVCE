<?php
include("../include/dbCompany.php");

session_start();
$output = '';
if(isset($_POST["export_excel"]))
{
    $sql = "select * from company_visited_2018";
    $fname = "CompanyList18_19";
    $result = mysqli_query($conCom,$sql);
    if(mysqli_num_rows($result)>0)
    {
        $output .='
            <table class="table table-bordered border" >
            <tr>
                                    <th>Name</th>
                                    <th>CTC</th>
                                    <th>HR Name</th>
                                    <th>HR Email</th>
                                    <th>HR Contact</th>
            </tr>
        ';
        while ($row=mysqli_fetch_array($result))
        {
            $output .= '
                <tr>
                    <td>'.$row["name"].'</td>
                    <td>'.$row["ctc"].'</td>
                    <td>'.$row["hrname"].'</td>
                    <td>'.$row["hremail"].'</td>
                    <td>'.$row["hrcontact"].'</td>                 
                </tr>
            ';
        }
        $output .='</table>';

        header("Content-Type: application/vnd.openxmlformats-officedocument.speadsheetml.sheet;charset=utf-8");

        header("Content-Disposition: attachment; filename=$fname.xls");
        echo $output;
    }
}
?>

