<?php
//error_reporting(0);
include("../include/dbCompany.php");


session_start();

$output = ''; //already existing in database
$invalidname = '';
$invalidrecord = '';

$temp = '';
if (isset($_POST["import"])) {
    $count = 0;
    $ct = 0;

    $bool = true;
    $flag = true;

    $takeExplode = explode(".", $_FILES["excel"]["name"]);
    $extension = end($takeExplode); // For getting Extension of selected file
    $allowed_extension = array("xls", "xlsx", "csv"); //allowed extension
    if (in_array($extension, $allowed_extension)) //check selected file extension is present in allowed extension array
    {
        $file = $_FILES["excel"]["tmp_name"]; // getting temporary source of excel file
        include("../../../admin/PHPExcel/Classes/PHPExcel/IOFactory.php"); // Add PHPExcel Library in this code
        $objPHPExcel = PHPExcel_IOFactory::load($file); // create object of PHPExcel library by using load() method and in load method define path of selected file
//      starting of table ended in studentToDb.php page
        $output .= "<div class=\"card mb-3\">";
        $output .= "<div class=\"card-header\"> <i class=\"fas fa-table\"></i>
                Error's in the uploaded excel data
            </div><div class=\"card-body\">
                <div class=\"table-responsive\">";
        $invalidname .= "<div class=\"table-responsive\">";
        $invalidrecord .= "<div class=\"table-responsive\">";
        $output .= "<table class=\"table table-bordered\" id=\"dataTable\" width=\"100%\" cellspacing=\"0\">
                        <thead>
                        <tr>
                            
                            <th>Name</th>
                            <th>CTC</th>
                            <th>HRName</th>
                            <th>HREmail</th>
                            <th>HRContact</th>
                        </tr>
                        </thead>";


        foreach ($objPHPExcel->getWorksheetIterator() as $worksheet) {
            $highestRow = $worksheet->getHighestRow();
            for ($row = 2; $row <= $highestRow; $row++) {

                $name = mysqli_real_escape_string($conCom, $worksheet->getCellByColumnAndRow(0, $row)->getValue());
                $ctc = mysqli_real_escape_string($conCom, $worksheet->getCellByColumnAndRow(1, $row)->getValue());

                $hrname = mysqli_real_escape_string($conCom, $worksheet->getCellByColumnAndRow(2, $row)->getValue());
                $hremail = mysqli_real_escape_string($conCom, $worksheet->getCellByColumnAndRow(3, $row)->getValue());
                $hrcontact = mysqli_real_escape_string($conCom, $worksheet->getCellByColumnAndRow(4, $row)->getValue());


                $sql2 = "select name from company_visited_2018";
                $data = mysqli_query($conCom, $sql2);
                $total = 0;
                $total = mysqli_num_rows($data);
                if ($total != 0) {
                    $rows = 0;
                    while ($rows = mysqli_fetch_assoc($data)) {
                        if ($rows['name'] == $name) {
                            $count = $count + 1;
                            $temp = $name;
                            $flag = false;

                            $output .= '<tr><td>' . $name . '</td>';
                            $output .= '<td>' . $ctc . '</td>';

//                            $output .= '<td>' . $hrname . '</td>';
//                            $output .= '<td>' . $hremail . '</td>';
//                            $output .= '<td>' . $hrcontact . '</td>';
                            $output .= '</tr>';
                        }
                    }
                }


                $year = 2018;

                if (!empty($name) ) {
                    if($flag) {
                        $query = "INSERT INTO  company_visited_2018(name, ctc, year, hrname, hremail, hrcontact) VALUES
                            ('" . $name . "', '" . $ctc . "','" . $year . "','" . $hrname . "', '" . $hremail . "', '" . $hrcontact . "')";
                        $bool = mysqli_query($conCom, $query);
                    }
                } else {

                    $ct = $ct + 1;

//                  if ($temp != $name) {
//                    $count = $count + 1;
//                      }
                    $invalidname .= '<tr><td>' . $name . '</td>';
                    $invalidname .= '<td>' . $ctc . '</td>';
//                    $invalidname .= '<td>' . $hrname . '</td>';
//                    $invalidname .= '<td>' . $hremail . '</td>';
//                    $invalidname .= '<td>' . $hrcontact . '</td>';
                    $invalidname .= '</tr>';
                }

            }
        }
        if ($count > 0) {
            echo " <script> alert('$count records are not inserted!');
                </script>";
           // echo "<script> window.history.replaceState( null, null, window.location.href='upload_company_18_19.php')</script>";

        } else {
            echo " <script> alert('Records are inserted!');
                </script>";
            echo "<script> window.history.replaceState( null, null, window.location.href='upload_company_year_18_19.php')</script>";

        }

    }
    else {
        $output = '<label class="text-danger">Invalid File</label>'; //if non excel file then
    }
}
?>
<!--html file upload to student database -->
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title> Upload | Student</title>
    <link rel="icon" type="image/png" href="../../img/rvlogo.png">

    <!-- Custom fonts for this template-->
    <link href="../../vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <!-- Page level plugin CSS-->
    <link href="../../vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="../../css/sb-admin.css" rel="stylesheet">

</head>

<body id="page-top">

<!--header start-->
<?php
include("./headerCompany_18_19.php");
?>

<div id="content-wrapper">
    <div class="container-fluid">
        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="../../../admin/dashboard.php">Dashboard</a>
            </li>
            <li class="breadcrumb-item active">Upload Student Details</li>
        </ol>
        <!--     content add here -->
        <div class="container-fluid">
            <h3 align="center">Upload to Student database</h3><br/>
            <form method="post" enctype="multipart/form-data">
                <label>Select Excel File</label>
                <input type="file" name="excel"/>
                <br/>
                <input type="submit" name="import" class="btn btn-info" value="Import"/>
            </form>
            <br/>
            <hr>
            <br/>
        </div>
        <!-- DataTables Example -->
        <!--imported from uploadStudent.php -->
        <tbody>
        <?php
        //        printing the record which is already in the database
        echo $output;
        //    printing the invalid usn records
        echo $invalidname;
        //        echo $invalidrecord;

        ?>
        </tbody>
        </table>

    </div>
</div>
</div>
<!--ending of table started in uploadStudent.php -->
</div>

<!--end  /.container-fluid -->
<!---------------------------------------------------------------------------------------------------------->

</div>
<!-- /.content-wrapper -->
</div>
<!-- /#wrapper -->
<!-------------------------------------------------------------------------------------------------------->
<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>


<!-- Bootstrap core JavaScript-->
<script src="../../vendor/jquery/jquery.min.js"></script>
<script src="../../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

<!-- Core plugin JavaScript-->
<script src="../../vendor/jquery-easing/jquery.easing.min.js"></script>

<!-- Page level plugin JavaScript-->
<script src="../../vendor/chart.js/Chart.min.js"></script>
<script src="../../vendor/datatables/jquery.dataTables.js"></script>
<script src="../../vendor/datatables/dataTables.bootstrap4.js"></script>

<!-- Custom scripts for all pages-->
<script src="../../js/sb-admin.min.js"></script>

<!-- Demo scripts for this page-->
<script src="../../js/demo/datatables-demo.js"></script>
<script src="../../js/demo/chart-area-demo.js"></script>


</body>

</html>




