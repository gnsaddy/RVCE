<?php
session_start();
include("./include/db.php");

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>crackTheCode Admin Area</title>
    <link rel="stylesheet" href="./css/bootstrap.css">
    <link rel="stylesheet" href="./css/font-awesome/css/fontawesome.min.css">
    <link rel="stylesheet" href="./css/style.css">
    <link rel="stylesheet" href="./css/login.css">
</head>

<body style="background-color: #1b1e21;">

<div class="container">
    <!-- container begin -->
    <form action="" class="form-login" method="post">
        <!-- form-login begin -->
        <h2 class="form-login-heading"> Admin Login </h2>


        <input type="text" class="form-control" placeholder="Email Address" name="admin_email" required>

        <input type="password" class="form-control" placeholder="Your Password" name="admin_pass" required>
        <!-- btn btn-lg btn-primary btn-block begin -->
        <button type="submit" class="btn btn-lg btn-block btn_color" name="admin_login">
            Login
        </button><!-- btn btn-lg btn-primary btn-block finish -->

    </form><!-- form-login finish -->
</div><!-- container finish -->

<?php
if (isset($_POST['admin_login'])) {
    $adminMail = $_POST['admin_email'];
    $adminPass = $_POST['admin_pass'];
    $query = "SELECT * FROM admins where admin_email='$adminMail' and admin_pass= '$adminPass' ";
    $userData = mysqli_query($con, $query);
    $totalrow = mysqli_num_rows($userData); // return the count of row
    if ($totalrow == 1) {
        $_SESSION['admin_mail'] = $adminMail;
        header('location: dashboard.php');
    } else {
        $msg = "Incorrect Email or password ";
        echo "<script type='text/javascript'> alert('$msg');</script>";
    }
}
?>

</body>

</html>