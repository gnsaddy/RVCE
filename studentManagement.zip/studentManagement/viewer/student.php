<?php
include("./include/db.php");
session_start();
?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Student</title>
    <!-- Bootstrap CSS  -->
    <link href="./css/bootstrap.css" rel="stylesheet">
    <!-- Our Custom CSS -->
    <link rel="stylesheet" href="./css/style3.css">
    <link href="./css/floatButton.css" rel="stylesheet">
    <link href="css/cardStyle.css" rel="stylesheet">
    <link href="./css/footer.css" rel="stylesheet">
    <!-- Scrollbar Custom CSS -->
    <link href="./css/jqueryScrollBar.css">

    <!-- Font Awesome JS -->
    <link href="./css/font-awesome/css/all.css" rel="stylesheet">
    <link href="./css/font-awesome/css/fontawesome.min.css" rel="stylesheet">
    <script src="./css/font-awesome/js/all.js"></script>
    <script src="./css/font-awesome/js/all.min.js"></script>
    <script src="./css/font-awesome/js/solid.js"></script>



</head>

<body>
<div class="wrapper">
    <!--adding header file-->
    <?php
    include("./headerAll.php");
    ?>
    <!--end -->
    <!--        page main content -->
    <div class="container-fluid">
        <!-- Icon Cards-->
        <div class="row">
            <div class="col-xl-3 col-sm-6 mb-3">
                <div class="card text-white bg-primary o-hidden h-100">
                    <div class="card-body">
                        <div class="card-body-icon">
                            <i class="fa fas fa-user-tie"></i>
                        </div>
                        <div class="mr-3">
                            <?php
                            $sql = "select count(usn) as 'Selected Student' from student";
                            $data = mysqli_query($con, $sql);
                            $result = mysqli_fetch_assoc($data);
                            echo $result['Selected Student'] . ' Selected Student !';
                            ?>
                        </div>
                    </div>
                    <a class="card-footer text-white clearfix small z-1" href="selectedStudent.php">
                        <span class="float-left">View Details</span>
                        <span class="float-right">
                                <i class="fas fa-angle-right"></i>
                            </span>
                    </a>
                </div>
            </div>
            <div class="col-xl-3 col-sm-6 mb-3">
                <div class="card text-white bg-warning o-hidden h-100">
                    <div class="card-body">
                        <div class="card-body-icon">
                            <i class="fa fas fa-graduation-cap"></i>
                        </div>
                        <div class="mr-5">
                            <?php
                            $sql = "select count(usn) as 'Alumni' from alumni";
                            $data = mysqli_query($con, $sql);
                            $result = mysqli_fetch_assoc($data);
                            echo $result['Alumni'] . ' Alumi !';
                            ?>
                        </div>
                    </div>
                    <a class="card-footer text-white clearfix small z-1" href="./alumniView.php">
                        <span class="float-left">View Details</span>
                        <span class="float-right">
                                <i class="fas fa-angle-right"></i>
                            </span>
                    </a>
                </div>
            </div>
            <div class="col-xl-3 col-sm-6 mb-3">
                <div class="card text-white bg-success o-hidden h-100">
                    <div class="card-body">
                        <div class="card-body-icon">
                            <i class="fa fas fa-briefcase"></i>
                        </div>
                        <div class="mr-3">123 Companies visited!</div>
                    </div>
                    <a class="card-footer text-white clearfix small z-1" href="#">
                        <span class="float-left">View Details</span>
                        <span class="float-right">
                                <i class="fas fa-angle-right"></i>
                            </span>
                    </a>
                </div>
            </div>
            <div class="col-xl-3 col-sm-6 mb-3">
                <div class="card text-white bg-danger o-hidden h-100">
                    <div class="card-body">
                        <div class="card-body-icon">
                            <i class="fas fa-fw fa-life-ring"></i>
                        </div>
                        <div class="mr-5">13 New Tickets!</div>
                    </div>
                    <a class="card-footer text-white clearfix small z-1" href="#">
                        <span class="float-left">View Details</span>
                        <span class="float-right">
                                <i class="fas fa-angle-right"></i>
                            </span>
                    </a>
                </div>
            </div>
        </div>
    </div>
    <!--    end of cards-->
    <!--    ********************************************************************************************************************  -->
    <div class="line"></div>


    <!--        end main start -->
    <!--    ********************************************************************************************************************  -->
    <!--  floating button  -->
    <div>
        <a class="float" href="#">
            <i class="fa fas fa-comment-dots my-float"></i>
        </a>
        <div class="label-container">
            <div class="label-text">Chat with us</div>
            <i class="fa fa-play label-arrow"></i>
        </div>
    </div>
    <!--    ********************************************************************************************************************  -->
    <!-- Sticky Footer -->
    <?php
    include("./include/footer.php");
    ?>
    <!--    ********************************************************************************************************************  -->
</div>
</div>

<!--    ********************************************************************************************************************  -->

<div class="overlay"></div>

<!-- jQuery CDN - Slim version (=without AJAX) -->
<script src="./css/jquery.js"></script>
<!-- Popper.JS -->
<script src="./css/popper.js"></script>
<!-- Bootstrap JS -->
<script src="./css/bootstrap.js"></script>
<!-- jQuery Custom Scroller CDN -->
<script src="./css/scrollbar.js"></script>

<script src="./css/scrollFunction.js"></script>

<!--*****************************************************************************************-->
<!--tables and charts-->
<!-- Core plugin JavaScript-->
<script src="vendor/jquery-easing/jquery.easing.min.js"></script>

<!-- Page level plugin JavaScript-->
<script src="vendor/chart.js/Chart.min.js"></script>
<script src="vendor/datatables/jquery.dataTables.js"></script>
<script src="vendor/datatables/dataTables.bootstrap4.js"></script>


<!-- Demo scripts for this page-->
<script src="js/demo/datatables-demo.js"></script>
<script src="js/demo/chart-area-demo.js"></script>

<!--    ********************************************************************************************************************  -->
</body>

</html>