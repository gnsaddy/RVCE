<?php
include("./include/db.php");
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Selected Student</title>
    <!-- Bootstrap CSS  -->
    <link href="css/bootstrap.css" rel="stylesheet">
    <!-- Our Custom CSS -->
    <link rel="stylesheet" href="css/style3.css">
    <link href="css/floatButton.css" rel="stylesheet">
    <link href="css/cardStyle.css" rel="stylesheet">
    <link href="css/footer.css" rel="stylesheet">
    <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
    <!-- Scrollbar Custom CSS -->
    <link href="css/jqueryScrollBar.css">

    <!-- Font Awesome JS -->
    <link href="css/font-awesome/css/all.css" rel="stylesheet">
    <link href="css/font-awesome/css/fontawesome.min.css" rel="stylesheet">
    <script src="css/font-awesome/js/all.js"></script>
    <script src="css/font-awesome/js/all.min.js"></script>
    <script src="css/font-awesome/js/solid.js"></script>



</head>

<body>
    <div class="wrapper">
        <!--adding header file-->
        <?php
        include("./headerAll.php");
        ?>
        <!--end -->
        <!--        page main content -->
        <div class="container-fluid">
            <!-- Breadcrumbs-->
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="index.php">Home</a>
                </li>
                <li class="breadcrumb-item active">Student Details</li>
            </ol>
            <!--     content add here -->


            <hr>
            <!-- DataTables Example -->
            <div class="card mb-3">
                <div class="card-header">
                    <i class="fas fa-table"></i>
                    Selected Student Data
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <?php
                        $sql = "select usn, name, email, contact, placed_year, offer1, salary1, offer2, salary2, offer3, salary3 from student";
                        $data = mysqli_query($con, $sql);
                        $total = mysqli_num_rows($data);
                        if ($total != 0) {
                            ?>
                        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                            <thead>

                                <tr>
                                    <th>USN</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Contact</th>
                                    <th>Placed Year</th>
                                    <th>Offer1</th>
                                    <th>Salary</th>
                                    <th>Offer2</th>
                                    <th>Salary</th>
                                    <th>Offer3</th>
                                    <th>Salary</th>
                                </tr>

                            </thead>
                            <tbody>

                                <?php
                                    while ($row = mysqli_fetch_assoc($data)) {
                                        echo "<tr><td>" . $row['usn'] . "</td>";
                                        echo "<td>" . $row['name'] . "</td>";
                                        echo "<td>" . $row['email'] . "</td>";
                                        echo "<td>" . $row['contact'] . "</td>";
                                        echo "<td>" . $row['placed_year'] . "</td>";
                                        echo "<td>" . $row['offer1'] . "</td>";
                                        echo "<td>" . $row['salary1'] . "</td>";
                                        echo "<td>" . $row['offer2'] . "</td>";
                                        echo "<td>" . $row['salary2'] . "</td>";
                                        echo "<td>" . $row['offer3'] . "</td>";
                                        echo "<td>" . $row['salary3'] . "</td></tr>";
                                    }
                                } else {
                                    echo "No records found!";
                                }
                                $con->close();

                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="card-footer small text-muted">Updated yesterday at 11:59 PM</div>
            </div>
        </div>

        <!--    ********************************************************************************************************************  -->
        <div class="line"></div>


        <!--        end main start -->
        <!--    ********************************************************************************************************************  -->
        <!--  floating button  -->
        <div>
            <a class="float" href="#">
                <i class="fa fas fa-comment-dots my-float"></i>
            </a>
            <div class="label-container">
                <div class="label-text">Chat with us</div>
                <i class="fa fa-play label-arrow"></i>
            </div>
        </div>
        <!--    ********************************************************************************************************************  -->
        <!-- Sticky Footer -->
        <?php
        include("./include/footer.php");
        ?>
        <!--    ********************************************************************************************************************  -->
    </div>
    </div>

    <!--    ********************************************************************************************************************  -->

    <div class="overlay"></div>

    <!-- jQuery CDN - Slim version (=without AJAX) -->
    <script src="css/jquery.js"></script>
    <!-- Popper.JS -->
    <script src="css/popper.js"></script>
    <!-- Bootstrap JS -->
    <script src="css/bootstrap.js"></script>
    <!-- jQuery Custom Scroller CDN -->
    <script src="css/scrollbar.js"></script>

    <script src="css/scrollFunction.js"></script>

    <!--*****************************************************************************************-->
    <!--tables and charts-->
    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Page level plugin JavaScript-->
    <script src="vendor/chart.js/Chart.min.js"></script>
    <script src="vendor/datatables/jquery.dataTables.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.js"></script>


    <!-- Demo scripts for this page-->
    <script src="js/demo/datatables-demo.js"></script>
    <script src="js/demo/chart-area-demo.js"></script>

    <!--    ********************************************************************************************************************  -->
</body>

</html>